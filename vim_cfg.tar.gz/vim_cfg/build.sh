find /home/jarvis/project/android/msm-4.14/ -path "/home/jarvis/project/android/msm-4.14/arch" -prune -o  -name "*.S" -name "*.s" -name "*.c" -o -name "*.cpp" -o -name "*.h" -o -name "*.hpp"\
	   	> cscope.files

find /home/jarvis/project/android/msm-4.14/arch/arm64 -name "*.S" -name "*.s" -name "*.c" -o -name "*.cpp" -o -name "*.h" -o -name "*.hpp"\
	   	>> cscope.files
cscope -q -R -b -i cscope.files
